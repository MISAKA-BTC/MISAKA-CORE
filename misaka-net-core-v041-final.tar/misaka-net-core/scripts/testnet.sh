#!/bin/bash
# MISAKA Testnet Launcher
# Starts N validator nodes locally for testing.
#
# Usage:
#   ./scripts/testnet.sh           # 4 validators, 10s blocks
#   ./scripts/testnet.sh 2 60      # 2 validators, 60s blocks
#   ./scripts/testnet.sh stop      # stop all nodes

set -e

VALIDATORS=${1:-4}
BLOCK_TIME=${2:-10}
BASE_RPC_PORT=3001
BASE_P2P_PORT=6690
LOG_DIR="./testnet-logs"
PID_FILE="./testnet.pids"

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

stop_testnet() {
    if [ -f "$PID_FILE" ]; then
        echo -e "${YELLOW}Stopping testnet...${NC}"
        while read pid; do
            kill "$pid" 2>/dev/null || true
        done < "$PID_FILE"
        rm -f "$PID_FILE"
        echo -e "${GREEN}Testnet stopped.${NC}"
    else
        echo "No testnet running."
    fi
}

if [ "$1" = "stop" ]; then
    stop_testnet
    exit 0
fi

# Stop any existing testnet
stop_testnet 2>/dev/null

# Build
echo -e "${BLUE}Building MISAKA node...${NC}"
cargo build --release -p misaka-node 2>&1 | tail -3
NODE_BIN="./target/release/misaka-node"

if [ ! -f "$NODE_BIN" ]; then
    echo "Build failed. Trying debug build..."
    cargo build -p misaka-node 2>&1 | tail -3
    NODE_BIN="./target/debug/misaka-node"
fi

# Setup
mkdir -p "$LOG_DIR"
rm -f "$PID_FILE"

echo ""
echo -e "${GREEN}╔═══════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║  MISAKA Testnet Launcher                             ║${NC}"
echo -e "${GREEN}║  Validators: ${VALIDATORS}   Block Time: ${BLOCK_TIME}s                    ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════╝${NC}"
echo ""

# Build peer list for each node
for i in $(seq 0 $((VALIDATORS - 1))); do
    RPC_PORT=$((BASE_RPC_PORT + i))
    P2P_PORT=$((BASE_P2P_PORT + i))

    # Build peer list (all other nodes)
    PEERS=""
    for j in $(seq 0 $((VALIDATORS - 1))); do
        if [ "$j" != "$i" ]; then
            if [ -n "$PEERS" ]; then
                PEERS="${PEERS},"
            fi
            PEERS="${PEERS}127.0.0.1:$((BASE_P2P_PORT + j))"
        fi
    done

    LOG_FILE="${LOG_DIR}/node-${i}.log"

    echo -e "${BLUE}Starting node-${i}${NC} | RPC=:${RPC_PORT} | P2P=:${P2P_PORT}"

    $NODE_BIN \
        --name "node-${i}" \
        --validator-index "$i" \
        --validators "$VALIDATORS" \
        --rpc-port "$RPC_PORT" \
        --p2p-port "$P2P_PORT" \
        --block-time "$BLOCK_TIME" \
        --peers "$PEERS" \
        --log-level info \
        > "$LOG_FILE" 2>&1 &

    echo $! >> "$PID_FILE"
    echo "   PID=$! | Log=${LOG_FILE}"
done

echo ""
echo -e "${GREEN}Testnet started with ${VALIDATORS} validators.${NC}"
echo ""
echo "Monitor:"
echo "  tail -f ${LOG_DIR}/node-0.log"
echo ""
echo "Status:"
echo "  curl -s -X POST http://127.0.0.1:3001/api/get_chain_info -H 'Content-Type: application/json' -d '{}' | jq ."
echo ""
echo "Explorer:"
echo "  NEXT_PUBLIC_USE_MOCK=false NEXT_PUBLIC_MISAKA_RPC_URL=http://127.0.0.1:3001 npm run dev"
echo ""
echo "Stop:"
echo "  ./scripts/testnet.sh stop"
