//! MISAKA Network — PQ-first UTXO node.
//!
//! Usage:
//!   misaka-node                          # run with defaults
//!   misaka-node --rpc-port 3001          # custom RPC port
//!   misaka-node --block-time 10          # fast blocks for testing
//!   misaka-node --peers 127.0.0.1:6691   # connect to peer

pub mod config;
pub mod chain_store;
pub mod block_producer;
pub mod rpc_server;
pub mod p2p_network;
pub mod sync;

pub use misaka_execution::block_apply::{self, execute_block, rollback_last_block, BlockResult};

use clap::Parser;
use std::net::SocketAddr;
use std::sync::Arc;
use tokio::sync::RwLock;
use tracing::{info, Level};
use tracing_subscriber::FmtSubscriber;

use crate::block_producer::{NodeState, SharedState};
use crate::chain_store::ChainStore;

#[derive(Parser, Debug)]
#[command(name = "misaka-node", version, about = "MISAKA Network validator node")]
struct Cli {
    /// Node name
    #[arg(long, default_value = "misaka-node-0")]
    name: String,

    /// RPC listen port
    #[arg(long, default_value = "3001")]
    rpc_port: u16,

    /// P2P listen port
    #[arg(long, default_value = "6690")]
    p2p_port: u16,

    /// Block time in seconds
    #[arg(long, default_value = "60")]
    block_time: u64,

    /// Validator index (for multi-validator testnet)
    #[arg(long, default_value = "0")]
    validator_index: usize,

    /// Total validator count
    #[arg(long, default_value = "1")]
    validators: usize,

    /// Static peers (comma-separated, e.g. 127.0.0.1:6691,127.0.0.1:6692)
    #[arg(long, value_delimiter = ',')]
    peers: Vec<String>,

    /// Data directory
    #[arg(long, default_value = "./data")]
    data_dir: String,

    /// Log level (trace, debug, info, warn, error)
    #[arg(long, default_value = "info")]
    log_level: String,

    /// Chain ID
    #[arg(long, default_value = "2")]
    chain_id: u32,
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let cli = Cli::parse();

    // Setup tracing
    let level = match cli.log_level.as_str() {
        "trace" => Level::TRACE,
        "debug" => Level::DEBUG,
        "warn" => Level::WARN,
        "error" => Level::ERROR,
        _ => Level::INFO,
    };
    let subscriber = FmtSubscriber::builder()
        .with_max_level(level)
        .with_target(false)
        .with_thread_ids(false)
        .compact()
        .finish();
    tracing::subscriber::set_global_default(subscriber)?;

    // Banner
    info!("╔═══════════════════════════════════════════════════════════╗");
    info!("║  MISAKA Network v0.4.1 — Post-Quantum Privacy L1       ║");
    info!("║  Consensus: BFT with Hybrid Signatures                  ║");
    info!("║  TX Privacy: Lattice Ring Sig + ML-KEM Stealth          ║");
    info!("╚═══════════════════════════════════════════════════════════╝");

    // Initialize chain store with genesis
    let now_ms = chrono::Utc::now().timestamp_millis() as u64;
    let mut chain = ChainStore::new();
    let genesis = chain.store_genesis(now_ms);
    info!(
        "Genesis block: height=0 hash={}",
        hex::encode(&genesis.hash[..8])
    );

    // Build shared state
    let state: SharedState = Arc::new(RwLock::new(NodeState {
        chain,
        height: 0,
        tx_count_total: 0,
        validator_count: cli.validators,
        genesis_timestamp_ms: now_ms,
        chain_id: cli.chain_id,
        chain_name: if cli.chain_id == 1 {
            "MISAKA Mainnet".into()
        } else {
            "MISAKA Testnet".into()
        },
        version: "v0.4.1".into(),
        pending_txs: std::collections::VecDeque::new(),
        spent_key_images: std::collections::HashSet::new(),
        faucet_drips: std::collections::HashMap::new(),
    }));

    // Parse peer addresses
    let static_peers: Vec<SocketAddr> = cli.peers.iter()
        .filter_map(|s| s.parse().ok())
        .collect();

    // Start P2P network
    let p2p = Arc::new(p2p_network::P2pNetwork::new(cli.chain_id, cli.name.clone()));
    let p2p_addr: SocketAddr = format!("0.0.0.0:{}", cli.p2p_port).parse()?;
    p2p.start_listener(p2p_addr).await?;

    if !static_peers.is_empty() {
        info!("Connecting to {} static peers...", static_peers.len());
        p2p.connect_to_peers(&static_peers, 0).await;
    }

    // Start RPC server
    let rpc_addr: SocketAddr = format!("0.0.0.0:{}", cli.rpc_port).parse()?;
    let rpc_state = state.clone();
    tokio::spawn(async move {
        if let Err(e) = rpc_server::run_rpc_server(rpc_state, rpc_addr).await {
            tracing::error!("RPC server error: {}", e);
        }
    });

    info!(
        "Node '{}' started | RPC={} | P2P={} | block_time={}s | validator={}/{}",
        cli.name, rpc_addr, p2p_addr, cli.block_time,
        cli.validator_index, cli.validators
    );
    info!("Chain: {} (id={})", if cli.chain_id == 1 { "Mainnet" } else { "Testnet" }, cli.chain_id);

    // Start block producer (blocks forever)
    block_producer::run_block_producer(
        state.clone(),
        cli.block_time,
        cli.validator_index,
    ).await;

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_chain_store_genesis() {
        let mut chain = ChainStore::new();
        let g = chain.store_genesis(1_700_000_000_000);
        assert_eq!(g.height, 0);
        assert_ne!(g.hash, [0u8; 32]);
    }
}
