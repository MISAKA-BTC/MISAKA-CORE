//! P2P network — TCP transport for block/TX propagation.
//!
//! Phase 2: Simple TCP connections to static peers.
//! Messages: NewBlock, NewTx, Vote, RequestBlock.

use std::collections::HashMap;
use std::net::SocketAddr;
use std::sync::Arc;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::{TcpListener, TcpStream};
use tokio::sync::{RwLock, broadcast};
use tracing::{info, warn, error};
use serde::{Serialize, Deserialize};

/// P2P message types.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum P2pMessage {
    /// Announce a new block header.
    NewBlock {
        height: u64,
        hash: [u8; 32],
        parent_hash: [u8; 32],
        timestamp_ms: u64,
        tx_count: usize,
        proposer_index: usize,
    },
    /// Request a block by height.
    RequestBlock { height: u64 },
    /// Ping/Pong for keepalive.
    Ping { nonce: u64 },
    Pong { nonce: u64 },
    /// Announce this node's identity.
    Hello {
        chain_id: u32,
        height: u64,
        node_name: String,
    },
}

impl P2pMessage {
    /// Serialize to length-prefixed JSON bytes.
    pub fn encode(&self) -> Vec<u8> {
        let json = serde_json::to_vec(self).unwrap();
        let len = (json.len() as u32).to_be_bytes();
        let mut buf = Vec::with_capacity(4 + json.len());
        buf.extend_from_slice(&len);
        buf.extend_from_slice(&json);
        buf
    }

    /// Deserialize from JSON bytes (no length prefix).
    pub fn decode(data: &[u8]) -> Result<Self, serde_json::Error> {
        serde_json::from_slice(data)
    }
}

/// Connected peer info.
#[derive(Debug)]
struct ConnectedPeer {
    addr: SocketAddr,
    node_name: String,
    height: u64,
}

/// P2P network manager.
pub struct P2pNetwork {
    peers: Arc<RwLock<HashMap<SocketAddr, ConnectedPeer>>>,
    broadcast_tx: broadcast::Sender<P2pMessage>,
    chain_id: u32,
    node_name: String,
}

impl P2pNetwork {
    pub fn new(chain_id: u32, node_name: String) -> Self {
        let (broadcast_tx, _) = broadcast::channel(256);
        Self {
            peers: Arc::new(RwLock::new(HashMap::new())),
            broadcast_tx,
            chain_id,
            node_name,
        }
    }

    /// Broadcast a message to all connected peers.
    pub fn broadcast(&self, msg: P2pMessage) {
        let _ = self.broadcast_tx.send(msg);
    }

    /// Get connected peer count.
    pub async fn peer_count(&self) -> usize {
        self.peers.read().await.len()
    }

    /// Start listening for incoming connections.
    pub async fn start_listener(&self, addr: SocketAddr) -> anyhow::Result<()> {
        let listener = TcpListener::bind(addr).await?;
        info!("P2P listening on {}", addr);

        let peers = self.peers.clone();
        let chain_id = self.chain_id;
        let node_name = self.node_name.clone();
        let broadcast_tx = self.broadcast_tx.clone();

        tokio::spawn(async move {
            loop {
                match listener.accept().await {
                    Ok((stream, peer_addr)) => {
                        info!("Inbound peer connected: {}", peer_addr);
                        let peers = peers.clone();
                        let node_name = node_name.clone();
                        let mut rx = broadcast_tx.subscribe();

                        tokio::spawn(async move {
                            if let Err(e) = handle_peer(stream, peer_addr, peers.clone(), chain_id, &node_name, &mut rx).await {
                                warn!("Peer {} disconnected: {}", peer_addr, e);
                            }
                            peers.write().await.remove(&peer_addr);
                        });
                    }
                    Err(e) => error!("Accept error: {}", e),
                }
            }
        });

        Ok(())
    }

    /// Connect to static peers.
    pub async fn connect_to_peers(&self, addrs: &[SocketAddr], our_height: u64) {
        for &addr in addrs {
            let peers = self.peers.clone();
            let chain_id = self.chain_id;
            let node_name = self.node_name.clone();
            let mut rx = self.broadcast_tx.subscribe();
            let height = our_height;

            tokio::spawn(async move {
                match TcpStream::connect(addr).await {
                    Ok(stream) => {
                        info!("Connected to peer: {}", addr);
                        // Send Hello
                        let hello = P2pMessage::Hello {
                            chain_id,
                            height,
                            node_name: node_name.clone(),
                        };
                        let data = hello.encode();
                        let (mut reader, mut writer) = stream.into_split();
                        if writer.write_all(&data).await.is_err() {
                            return;
                        }

                        // Read loop
                        let peers_clone = peers.clone();
                        tokio::spawn(async move {
                            let mut buf = [0u8; 4];
                            loop {
                                if reader.read_exact(&mut buf).await.is_err() { break; }
                                let len = u32::from_be_bytes(buf) as usize;
                                if len > 1_000_000 { break; }
                                let mut msg_buf = vec![0u8; len];
                                if reader.read_exact(&mut msg_buf).await.is_err() { break; }
                                match P2pMessage::decode(&msg_buf) {
                                    Ok(P2pMessage::Hello { node_name: name, height, .. }) => {
                                        peers_clone.write().await.insert(addr, ConnectedPeer {
                                            addr, node_name: name, height,
                                        });
                                    }
                                    Ok(P2pMessage::NewBlock { height, .. }) => {
                                        info!("Peer {} announced block #{}", addr, height);
                                    }
                                    Ok(P2pMessage::Ping { nonce }) => {
                                        // Pong handled in write loop
                                        let _ = nonce;
                                    }
                                    _ => {}
                                }
                            }
                        });

                        // Write loop: forward broadcasts
                        tokio::spawn(async move {
                            while let Ok(msg) = rx.recv().await {
                                let data = msg.encode();
                                if writer.write_all(&data).await.is_err() { break; }
                            }
                        });
                    }
                    Err(e) => {
                        warn!("Failed to connect to {}: {}", addr, e);
                    }
                }
            });
        }
    }
}

async fn handle_peer(
    stream: TcpStream,
    addr: SocketAddr,
    peers: Arc<RwLock<HashMap<SocketAddr, ConnectedPeer>>>,
    chain_id: u32,
    node_name: &str,
    rx: &mut broadcast::Receiver<P2pMessage>,
) -> anyhow::Result<()> {
    let (mut reader, mut writer) = stream.into_split();

    // Send Hello
    let hello = P2pMessage::Hello {
        chain_id,
        height: 0,
        node_name: node_name.to_string(),
    };
    writer.write_all(&hello.encode()).await?;

    // Read first message (expect Hello)
    let mut len_buf = [0u8; 4];
    reader.read_exact(&mut len_buf).await?;
    let len = u32::from_be_bytes(len_buf) as usize;
    let mut msg_buf = vec![0u8; len];
    reader.read_exact(&mut msg_buf).await?;

    if let Ok(P2pMessage::Hello { node_name: name, height, chain_id: their_chain }) = P2pMessage::decode(&msg_buf) {
        if their_chain != chain_id {
            anyhow::bail!("chain_id mismatch: ours={} theirs={}", chain_id, their_chain);
        }
        peers.write().await.insert(addr, ConnectedPeer {
            addr, node_name: name.clone(), height,
        });
        info!("Peer {} identified: {} (height={})", addr, name, height);
    }

    // Forward broadcasts to this peer
    loop {
        match rx.recv().await {
            Ok(msg) => {
                if writer.write_all(&msg.encode()).await.is_err() {
                    break;
                }
            }
            Err(_) => break,
        }
    }

    Ok(())
}
