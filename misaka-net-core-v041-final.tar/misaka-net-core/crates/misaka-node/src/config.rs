//! Node configuration — parsed from CLI args or defaults.

use std::net::SocketAddr;

/// Node configuration.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct NodeConfig {
    /// Human-readable node name.
    pub node_name: String,
    /// Data directory for chain state.
    pub data_dir: String,
    /// RPC listen address.
    pub rpc_addr: SocketAddr,
    /// P2P listen address.
    pub p2p_addr: SocketAddr,
    /// Static peer addresses for initial connection.
    pub static_peers: Vec<SocketAddr>,
    /// Whether this node is a block proposer.
    pub is_proposer: bool,
    /// Validator index (0-based, for testnet).
    pub validator_index: usize,
    /// Block time target in seconds.
    pub block_time_secs: u64,
    /// Genesis config path (JSON). If empty, use built-in testnet default.
    pub genesis_path: String,
    /// Log level.
    pub log_level: String,
}

impl Default for NodeConfig {
    fn default() -> Self {
        Self {
            node_name: "misaka-node-0".into(),
            data_dir: "./data".into(),
            rpc_addr: "127.0.0.1:3001".parse().unwrap(),
            p2p_addr: "0.0.0.0:6690".parse().unwrap(),
            static_peers: vec![],
            is_proposer: true,
            validator_index: 0,
            block_time_secs: 60,
            genesis_path: String::new(),
            log_level: "info".into(),
        }
    }
}
